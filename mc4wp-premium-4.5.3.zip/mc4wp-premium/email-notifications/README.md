### MailChimp for WordPress - Email Notifications

This add-on plugin adds an email notification option to MailChimp for WordPress its sign-up forms.
### MailChimp for WordPress - Logging

This add-on plugin for [MailChimp for WordPress](https://mc4wp.com/) will keep track of (log) all sign-up requests.
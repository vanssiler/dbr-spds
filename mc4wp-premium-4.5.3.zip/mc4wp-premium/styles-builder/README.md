### MailChimp for WordPress - Form Styles Builder

This add-on plugin for [MailChimp for WordPress](https://mc4wp.com/) adds a Styles Builder. Using this Styles Builder, 
you can create stylesheets for your sign-up forms without writing a single line of CSS.